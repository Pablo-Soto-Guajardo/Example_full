package com.example.ms_libro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsLibroApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsLibroApplication.class, args);
	}

}
